@extends('layouts.main')
@section('main-container')
<div class="page-wrapper">
    <div class="page-breadcrumb bg-white">
        <div class="container">
            <div class="row justify-content-center">
            <div class="col-md-6">
                <h4 class="page-title">Products</h4><hr>
                <table class="table-border" width="100%">
                    <thead>
                        <td>Name</td>
                        <td>Price</td>
                        <td>Status</td>
                        <td>Action</td>
                    </thead>
                    <tbody>
                        @if($products->isNotEmpty())
                        @foreach ($products as $product)
                        <tr>
                            <td>{{$product->product_name}}</td>
                            <td>{{$product->product_price}}</td>
                            <td>{{$product->product_status}}</td>
                            <td>
                                <a href="{{url('profile/edit')}}/{{$product->product_id}}" class="btn btn-primary">Update</a>
                                <a href="{{url('profile/delete')}}/{{$product->product_id}}" class="btn btn-danger">Delete</a>
                            </td>
                        </tr>
                        @endforeach
                        @endif
                    </tbody>
                </table>
        <form action="{{url('profile/store')}}" method="post">
            @csrf
            <div class="form-group">
            <label>Product Name</label>
            <input type="text" class="form-control" name="product_name" value="{{old('product_category_name')}}">
            <small class="text-danger">{{$errors->first('product_name')}}</small>
            </div>

            <div class="form-group">
                <label>Product Price</label>
                <input type="number" class="form-control" name="product_price" value="{{old('product_price')}}">
                <small class="text-danger">{{$errors->first('product_price')}}</small>
            </div>

            <div class="form-group">
                <label>Product Description</label>
                <textarea type="text" class="form-control" name="product_description"></textarea>
            </div>

            <div class="form-group">
                <input type="submit" class="btn btn-primary" name="submit" value="Submit">
            </div>


        </form>
    </div>
    </div>
    </div>
    </div>
</div>
@endsection     