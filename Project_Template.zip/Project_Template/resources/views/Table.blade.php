@extends('layouts.main')
@section('main-container')

<table class="table-border" width="100%">
    <thead>
        <td>Name</td>
        <td>Price</td>
        <td>Status</td>
        <td>Action</td>
    </thead>
    <tbody>
        @if($products->isNotEmpty())
        @foreach ($products as $product)
        <tr>
            <td>{{$product->product_name}}</td>
            <td>{{$product->product_price}}</td>
            <td>{{$product->product_status}}</td>
            <td>
                <a href="{{url('profile/edit')}}/{{$product->product_id}}" class="btn btn-primary">Update</a>
                <a href="{{url('profile/delete')}}/{{$product->product_id}}" class="btn btn-danger">Delete</a>
            </td>
        </tr>
        @endforeach
        @endif
    </tbody>
</table>
@endsection