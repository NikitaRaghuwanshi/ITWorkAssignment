@extends('layouts.main')
@section('main-container')
<div class="page-wrapper">
    <div class="page-breadcrumb bg-white">
        <div class="container">
            <div class="row justify-content-center">
            <div class="col-md-6">
                    

                    <form action="{{url('profile/update')}}" method="POST">
                        @csrf
                        <input type="hidden" name="product_id" value="{{$product->product_id}}">
                        <div class="form-group">
                            <label>Product Name</label>
                            <input type="text" class="form-control" name="product_name" value="{{$product->product_name}}">
                            <small class="text-danger">{{$errors->first('product_name')}}</small>
                            </div>
                
                            <div class="form-group">
                                <label>Product Price</label>
                                <input type="number" class="form-control" name="product_price" value="{{$product->product_price}}">
                                <small class="text-danger">{{$errors->first('product_price')}}</small>
                            </div>
                
                            <div class="form-group">
                                <label>Product Description</label>
                                <textarea type="text" class="form-control" name="product_description">{{$product->product_description}}</textarea>
                            </div>
                
                            <div class="form-group">
                                <input type="submit" class="btn btn-primary" name="submit" value="Submit">
                            </div>
                        {{-- <div class="form_group">
                        <label>Product Name</label>
                        <input type="text" class="form_control" name="product_name" value="{{$product->product_name}}">
                        <small class="text-danger">{{$errors->first('product_name')}}</small>
                        </div>

                        <div class="form_group">
                            <label>Product Price</label>
                            <input type="number" class="form_control" name="product_price" value="{{$product->product_price}}">
                            <small class="text-danger">{{$errors->first('product_price')}}</small>
                        </div>

                        <div class="form_group">
                            <label>Product Description</label>
                            <textarea type="text" class="form_control" name="product_description" >{{$product->product_description}}</textarea>
                        </div>

                        <div class="form_group">
                            <input type="submit" name="submit" value="submit">
                        </div> --}}
                    </form>
                </div>
            </div>
            </div>
            </div>
        </div>
        @endsection     
