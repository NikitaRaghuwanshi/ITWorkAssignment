
<?php $__env->startSection('main-container'); ?>

<table class="table-border" width="100%">
    <thead>
        <td>Name</td>
        <td>Price</td>
        <td>Status</td>
        <td>Action</td>
    </thead>
    <tbody>
        <?php if($products->isNotEmpty()): ?>
        <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td><?php echo e($product->product_name); ?></td>
            <td><?php echo e($product->product_price); ?></td>
            <td><?php echo e($product->product_status); ?></td>
            <td>
                <a href="<?php echo e(url('profile/edit')); ?>/<?php echo e($product->product_id); ?>" class="btn btn-primary">Update</a>
                <a href="<?php echo e(url('profile/delete')); ?>/<?php echo e($product->product_id); ?>" class="btn btn-danger">Delete</a>
            </td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php endif; ?>
    </tbody>
</table>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Laravel_Template\Project_Template\resources\views/table.blade.php ENDPATH**/ ?>