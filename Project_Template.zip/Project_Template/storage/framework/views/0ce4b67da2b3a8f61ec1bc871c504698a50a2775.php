
<?php $__env->startSection('main-container'); ?>
<div class="page-wrapper">
    <div class="page-breadcrumb bg-white">
        <div class="container">
            <div class="row justify-content-center">
            <div class="col-md-6">
                    

                    <form action="<?php echo e(url('profile/update')); ?>" method="POST">
                        <?php echo csrf_field(); ?>
                        <input type="hidden" name="product_id" value="<?php echo e($product->product_id); ?>">
                        <div class="form-group">
                            <label>Product Name</label>
                            <input type="text" class="form-control" name="product_name" value="<?php echo e($product->product_name); ?>">
                            <small class="text-danger"><?php echo e($errors->first('product_name')); ?></small>
                            </div>
                
                            <div class="form-group">
                                <label>Product Price</label>
                                <input type="number" class="form-control" name="product_price" value="<?php echo e($product->product_price); ?>">
                                <small class="text-danger"><?php echo e($errors->first('product_price')); ?></small>
                            </div>
                
                            <div class="form-group">
                                <label>Product Description</label>
                                <textarea type="text" class="form-control" name="product_description"><?php echo e($product->product_description); ?></textarea>
                            </div>
                
                            <div class="form-group">
                                <input type="submit" class="btn btn-primary" name="submit" value="Submit">
                            </div>
                        
                    </form>
                </div>
            </div>
            </div>
            </div>
        </div>
        <?php $__env->stopSection(); ?>     

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Laravel_Template\Project_Template\resources\views/edit.blade.php ENDPATH**/ ?>