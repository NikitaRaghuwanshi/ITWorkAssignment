<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Product;

class TableController extends Controller
{
    public function index()
    {
        return view('table');
    }
    public function edit($id)
    {
        // $product=Product::findorfail($id);
        $product=Product::where('product_id',$id)->first();
        // $product=Product::findorfail($id);
        // dd('product');
        // Product::where('product_id',$id)->first();
        return view('edit',compact('product'));
    }
    public function update(Request $request)
    {
        $input=$request->all();

        // Method-1
        // $product=Product::find($request->product_id);
        // $product=Product::find($input['product_id']);
        // $product->product_name=$input['product_name'];
        // $product->product_price=$input['product_price'];
        // $product->product_description=$input['product_description'];
        // $product->save();
        // return redirect('product');

        // Method-2
        unset($input['_token']);
        unset($input['submit']);
        Product::where('product_id',$input['product_id'])->update($input);
        toastr()->info('Update Successfully..');
        return redirect('table');

        // Method-3
        // $searchInput['product_id']=$input['product_id'];
        // Product::updateorcreate($searchInput,$input);
        // return redirect('product');
    }
    public function destroy($id)
    {
       Product::where('product_id',$id)->delete();
        toastr()->error('Delete Record Successfully..');
       return redirect('table');
    }
    
}
