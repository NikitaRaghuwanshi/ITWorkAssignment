<?php

namespace App\Http\Controllers;
use App\Models\Product;

use Illuminate\Http\Request;

class ProfileController extends Controller
{
    public function index()
    {
        $products=Product::where(['product_status'=>'Active'])->get();
        return view('profile',compact('products'));
    }
    public function store(Request $request)
    {
        $input=$request->all();
        $this->validate($request,[
            'product_name'=>'required|min:3',
            'product_price'=>'required'
           ]
        //    [
        //     'product_name'=>'Please, Enter name..'
        //    ]
        );

        // return Validator::make($input, [
        //     'product_name' => ['required', 'string', 'max:255'],
        //     'product_price' => ['required', 'max:255', 'unique:users'],
        // ]);     

            $product= Product::create($input);
            // dd($product);
            if($product){
                toastr()->success('Insert Record Successfully..');
                return redirect('profile');
            }
            // else 
            // {
            //     toastr()->error('Error Message');
            //     return redirect('product');
            // }

    }
    public function edit($id)
    {
        // $product=Product::findorfail($id);
        $product=Product::where('product_id',$id)->first();
        // $product=Product::findorfail($id);
        // dd('product');
        // Product::where('product_id',$id)->first();
        return view('edit',compact('product'));
    }
    public function update(Request $request)
    {
        $input=$request->all();

        // Method-1
        // $product=Product::find($request->product_id);
        // $product=Product::find($input['product_id']);
        // $product->product_name=$input['product_name'];
        // $product->product_price=$input['product_price'];
        // $product->product_description=$input['product_description'];
        // $product->save();
        // return redirect('product');

        // Method-2
        unset($input['_token']);
        unset($input['submit']);
        Product::where('product_id',$input['product_id'])->update($input);
        toastr()->info('Update Successfully..');
        return redirect('profile');

        // Method-3
        // $searchInput['product_id']=$input['product_id'];
        // Product::updateorcreate($searchInput,$input);
        // return redirect('product');
    }
    public function destroy($id)
    {
       Product::where('product_id',$id)->delete();
        toastr()->error('Delete Record Successfully..');
       return redirect('profile');
    }
    
}
