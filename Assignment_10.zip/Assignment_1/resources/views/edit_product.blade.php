@extends('layouts.app')
<head>
    <!-- Styles -->
    <link href="{{ asset('Frontend/CSS/bootstrap.min.css')}}" rel="stylesheet">
    <link href="{{ asset('Frontend/CSS/custom.css')}}" rel="stylesheet">
</head>

@section('content')
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header">Products</div>

                <div class="card-body">
                    

                    <form action="{{url('product/update')}}" method="POST">
                        @csrf
                        <input type="hidden" name="product_id" value="{{$product->product_id}}">
                        <div class="form_group">
                        <label>Product Name</label>
                        <input type="text" class="form_control" name="product_name" value="{{$product->product_name}}">
                        <small class="text-danger">{{$errors->first('product_name')}}</small>
                        </div>

                        <div class="form_group">
                            <label>Product Price</label>
                            <input type="number" class="form_control" name="product_price" value="{{$product->product_price}}">
                            <small class="text-danger">{{$errors->first('product_price')}}</small>
                        </div>

                        <div class="form_group">
                            <label>Product Description</label>
                            <textarea type="text" class="form_control" name="product_description" >{{$product->product_description}}</textarea>
                        </div>

                        <div class="form_group">
                            <input type="submit" name="submit" value="submit">
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
@endsection
