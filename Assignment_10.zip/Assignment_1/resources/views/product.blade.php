@extends('layouts.app')
{{-- <head>
    <!-- Styles -->
    <link href="{{ asset('Frontend/CSS/bootstrap.min.css')}}" rel="stylesheet">
    <link href="{{ asset('Frontend/CSS/custom.css')}}" rel="stylesheet">
</head> --}}

@section('content')
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header">Products</div>

                <div class="card-body">
                    <table class="table-border" width="100%">
                        <thead>
                            <td>Name</td>
                            <td>Price</td>
                            <td>Status</td>
                            <td>Action</td>
                        </thead>
                        <tbody>
                            @if($products->isNotEmpty())
                            @foreach ($products as $product)
                            <tr>
                                <td>{{$product->product_name}}</td>
                                <td>{{$product->product_price}}</td>
                                <td>{{$product->product_status}}</td>
                                <td>
                                    <a href="{{url('product/edit')}}/{{$product->product_id}}" class="btn btn-primary">Update</a>
                                    <a href="{{url('product/delete')}}/{{$product->product_id}}" class="btn btn-danger">Delete</a>
                                </td>
                            </tr>
                            @endforeach
                            @endif
                        </tbody>
                    </table>

                    <form action="{{url('product\store')}}" method="POST">
                        @csrf
                        <div class="form_group">
                        <label>Product Name</label>
                        <input type="text" class="form_control" name="product_name">
                        <small class="text-danger">{{$errors->first('product_name')}}</small>
                        </div>

                        <div class="form_group">
                            <label>Product Price</label>
                            <input type="number" class="form_control" name="product_price" value="{{old('product_name')}}">
                            <small class="text-danger">{{$errors->first('product_price')}}</small>
                        </div>

                        <div class="form_group">
                            <label>Product Description</label>
                            <textarea type="text" class="form_control" name="product_description"></textarea>
                        </div>

                        <div class="form_group">
                            <input type="submit" name="submit" value="submit">
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
@endsection
